
export const GRID_CONFIG = {
  DISTANCE_KM: 20,
  LOCATION_A: {
    NAME: "Upstream Reservoir (A)",
    THRESHOLD_MIN: 20, // Cannot give water if below this
    CRITICAL_CUTOFF: 5
  },
  LOCATION_B: {
    NAME: "Downstream Distribution (B)",
    REQUEST_THRESHOLD: 30, // Request water if below this
    CRITICAL_CUTOFF: 5
  },
  HEARTBEAT_INTERVAL_MS: 3000
};

export const DB_SCHEMA = `
-- Historical Water Flow Schema
CREATE TABLE water_telemetry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    timestamp TIMESTAMPTZ NOT NULL,
    location_id TEXT NOT NULL,
    tank_level_pct NUMERIC(5,2),
    flow_rate_lps NUMERIC(7,2),
    pump_1_amps NUMERIC(5,2),
    pump_2_amps NUMERIC(5,2),
    system_status TEXT
);

CREATE INDEX idx_telemetry_time ON water_telemetry (timestamp DESC);
CREATE INDEX idx_location_time ON water_telemetry (location_id, timestamp DESC);
`;

export const ESP32_LOGIC_CPP = `
/* 
 * ESP32 Smart Water Grid Logic (Self-Healing & Safety)
 * Implements ultrasonic sensing, redundant pump control, and hardcoded safety interrupts.
 */

#include <Arduino.h>

const int PIN_PUMP_1 = 26;
const int PIN_PUMP_2 = 27;
const int PIN_CURRENT_SENSE_1 = 34;
const int PIN_TRIG = 5;
const int PIN_ECHO = 18;

float get_level_pct() {
  // Ultrasonic logic for 2m deep tank
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long duration = pulseIn(PIN_ECHO, HIGH);
  float distance = duration * 0.034 / 2;
  float pct = ((200.0 - distance) / 200.0) * 100.0;
  return constrain(pct, 0.0, 100.0);
}

void loop() {
  float level = get_level_pct();
  float current1 = analogRead(PIN_CURRENT_SENSE_1) * (3.3 / 4095.0) * 30.0; // ACS712 math

  // 1. HARDCODED SAFETY: Dry-Run Prevention
  if (level < 5.0) {
    digitalWrite(PIN_PUMP_1, LOW);
    digitalWrite(PIN_PUMP_2, LOW);
    Serial.println("ALERT: Dry-Run Cutoff Triggered!");
    return; 
  }

  // 2. SELF-HEALING LOGIC
  bool pump1_commanded_on = digitalRead(PIN_PUMP_1);
  if (pump1_commanded_on && current1 < 0.2) { // Less than 0.2A while ON
    digitalWrite(PIN_PUMP_1, LOW); // Kill faulty pump
    digitalWrite(PIN_PUMP_2, HIGH); // Switch to redundant
    mqtt.publish("grid/errors", "PUMP_1_FAILURE_SWITCHING_TO_PUMP_2");
  }

  delay(1000);
}
`;
