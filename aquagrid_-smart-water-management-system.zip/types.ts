
export enum PumpStatus {
  OFF = 'OFF',
  ON = 'ON',
  ERROR = 'ERROR'
}

export interface PumpState {
  id: string;
  command: PumpStatus;
  actualStatus: PumpStatus;
  currentAmps: number;
  isRedundant: boolean;
}

export interface TankData {
  id: string;
  name: string;
  level: number; // 0 to 100
  pumps: PumpState[];
  flowRate: number; // L/s
  lastUpdate: number;
}

export interface GridAlert {
  id: string;
  timestamp: number;
  location: string;
  severity: 'low' | 'medium' | 'high';
  message: string;
}

export interface GridState {
  locationA: TankData;
  locationB: TankData;
  linkHealth: number; // 0 to 100
  alerts: GridAlert[];
}
