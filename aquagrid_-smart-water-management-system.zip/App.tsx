
import React, { useState, useEffect, useCallback } from 'react';
import { GridState } from './types';
import { mqttBus } from './services/mqttSimulator';
import { architectAI } from './services/geminiService';
import LocationCard from './components/LocationCard';
import { ESP32_LOGIC_CPP, DB_SCHEMA, GRID_CONFIG } from './constants';

const App: React.FC = () => {
  const [gridState, setGridState] = useState<GridState | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'edge' | 'ai'>('dashboard');
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  useEffect(() => {
    mqttBus.start();
    const unsubscribe = mqttBus.subscribe((state) => {
      setGridState(state);
    });
    return () => {
      mqttBus.stop();
      unsubscribe();
    };
  }, []);

  const handleAskAI = async () => {
    if (!aiQuery.trim()) return;
    setIsAiLoading(true);
    const res = await architectAI.getArchitectAdvice(aiQuery);
    setAiResponse(res);
    setIsAiLoading(false);
  };

  const simulateFailure = () => {
    mqttBus.forceFailure();
  };

  if (!gridState) return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-xl font-mono animate-pulse">Initializing Smart Water Grid...</div>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      {/* Top Header */}
      <header className="bg-slate-800/80 backdrop-blur-md border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white leading-none">AquaGrid OS</h1>
              <p className="text-[10px] text-slate-400 font-mono uppercase tracking-widest mt-1">Smart Water Management v4.2</p>
            </div>
          </div>

          <nav className="flex items-center gap-1">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === 'dashboard' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
            >
              Dashboard
            </button>
            <button 
              onClick={() => setActiveTab('edge')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === 'edge' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
            >
              Edge Logic
            </button>
            <button 
              onClick={() => setActiveTab('ai')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === 'ai' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:text-white hover:bg-slate-700/50'}`}
            >
              AI Architect
            </button>
          </nav>

          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${gridState.linkHealth > 90 ? 'bg-emerald-500' : 'bg-amber-500'} animate-pulse`} />
                <span className="text-xs font-mono text-slate-300">20KM LINK: {gridState.linkHealth.toFixed(1)}%</span>
              </div>
              <span className="text-[10px] text-slate-500 uppercase tracking-tighter">Encrypted MQTT Tunnel</span>
            </div>
            <button 
              onClick={simulateFailure}
              className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded text-xs font-bold transition-colors"
            >
              TEST FAILURE
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <LocationCard data={gridState.locationA} isSource />
              <LocationCard data={gridState.locationB} />
            </div>

            {/* Link Visualization */}
            <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700">
               <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase mb-4 tracking-[0.2em]">
                 <span>Location A</span>
                 <span>Subterranean Pipeline Network ({GRID_CONFIG.DISTANCE_KM}km)</span>
                 <span>Location B</span>
               </div>
               <div className="relative h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-700/50">
                  <div 
                    className="absolute h-full bg-gradient-to-r from-blue-600 via-cyan-400 to-blue-600 transition-all duration-1000"
                    style={{ width: '100%', opacity: gridState.locationA.flowRate > 0 ? 1 : 0.2 }}
                  />
               </div>
            </div>

            {/* Alert Logs */}
            <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden shadow-xl">
              <div className="px-4 py-3 bg-slate-700/50 border-b border-slate-600 flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-300 uppercase tracking-widest">Real-time Telemetry Alerts</h3>
                <span className="text-[10px] text-slate-500 font-mono uppercase">Live Feed</span>
              </div>
              <div className="h-48 overflow-y-auto font-mono text-xs">
                {gridState.alerts.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-slate-600 italic">No critical anomalies detected. System Nominal.</div>
                ) : (
                  gridState.alerts.map(alert => (
                    <div key={alert.id} className={`px-4 py-2 border-b border-slate-700/50 flex items-start gap-4 ${alert.severity === 'high' ? 'bg-red-500/5' : ''}`}>
                      <span className="text-slate-500 whitespace-nowrap">[{new Date(alert.timestamp).toLocaleTimeString()}]</span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                        alert.severity === 'high' ? 'bg-red-500 text-white' : 
                        alert.severity === 'medium' ? 'bg-amber-500 text-black' : 'bg-blue-500 text-white'
                      }`}>
                        {alert.severity.toUpperCase()}
                      </span>
                      <span className="text-slate-300 flex-1">{alert.message}</span>
                      <span className="text-[10px] text-slate-600 uppercase font-bold">{alert.location}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'edge' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">ESP32 Edge State Machine</h3>
                <span className="text-xs bg-slate-700 px-2 py-1 rounded text-slate-400">C++ / Arduino</span>
              </div>
              <pre className="bg-slate-900 p-4 rounded-lg overflow-x-auto text-[11px] text-emerald-400 font-mono leading-relaxed max-h-[500px]">
                {ESP32_LOGIC_CPP}
              </pre>
            </div>
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">Historical DB Schema</h3>
                <span className="text-xs bg-slate-700 px-2 py-1 rounded text-slate-400">PostgreSQL / TimeScaleDB</span>
              </div>
              <pre className="bg-slate-900 p-4 rounded-lg overflow-x-auto text-[11px] text-blue-400 font-mono leading-relaxed">
                {DB_SCHEMA}
              </pre>
              <div className="mt-6 p-4 bg-blue-900/20 rounded-lg border border-blue-500/20">
                <h4 className="text-sm font-bold text-blue-400 mb-2 uppercase tracking-wide">Architecture Notes</h4>
                <ul className="text-xs text-slate-300 space-y-2">
                  <li>• Use AWS IoT Core with X.509 certificates for the 20km long-range link.</li>
                  <li>• Location B acts as MQTT Publisher (Water Request).</li>
                  <li>• Location A acts as MQTT Subscriber & Control Logic Master.</li>
                  <li>• 5% level cutoff is hard-wired at the hardware interrupt level for fail-safe operation.</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-slate-800 p-8 rounded-2xl border border-slate-700 shadow-2xl">
              <h2 className="text-2xl font-bold text-white mb-2">IoT System Architect AI</h2>
              <p className="text-slate-400 mb-6 italic text-sm">Consult our AI architect for scaling advice, protocol selection, or troubleshooting edge logic.</p>
              
              <div className="flex gap-4">
                <input 
                  type="text" 
                  value={aiQuery}
                  onChange={(e) => setAiQuery(e.target.value)}
                  placeholder="Ask about MQTT topics, redundancy strategies, or ultrasonic calibration..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onKeyDown={(e) => e.key === 'Enter' && handleAskAI()}
                />
                <button 
                  onClick={handleAskAI}
                  disabled={isAiLoading}
                  className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold px-6 py-3 rounded-xl transition-all shadow-lg shadow-blue-500/20"
                >
                  {isAiLoading ? 'Thinking...' : 'Consult'}
                </button>
              </div>

              {aiResponse && (
                <div className="mt-8 p-6 bg-slate-900 rounded-xl border border-slate-700 animate-in fade-in slide-in-from-top-4 duration-500">
                  <div className="flex items-center gap-2 mb-4 text-blue-400 text-xs font-bold uppercase tracking-widest">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    Architect Feedback
                  </div>
                  <div className="prose prose-invert max-w-none text-slate-300 whitespace-pre-wrap leading-relaxed text-sm">
                    {aiResponse}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Persistent Call-to-Action for Health Monitoring */}
      <footer className="bg-slate-900 border-t border-slate-800 p-4 sticky bottom-0">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 font-bold uppercase">Grid Integrity</span>
              <div className="flex items-center gap-2">
                <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500" style={{ width: `${gridState.linkHealth}%` }} />
                </div>
                <span className="text-xs font-mono text-emerald-500">OPTIMAL</span>
              </div>
            </div>
            <div className="flex flex-col border-l border-slate-800 pl-8">
              <span className="text-[10px] text-slate-500 font-bold uppercase">System Uptime</span>
              <span className="text-xs font-mono text-white">124d 04h 22m</span>
            </div>
          </div>
          <div className="flex items-center gap-4 text-[10px] text-slate-500 uppercase tracking-widest font-mono">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> HiveMQ Cloud Connected
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> AWS IoT Relay Active
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
