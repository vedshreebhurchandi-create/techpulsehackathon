
import React from 'react';

interface GaugeProps {
  value: number;
  label: string;
  color?: string;
}

const Gauge: React.FC<GaugeProps> = ({ value, label, color = 'blue' }) => {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;

  const colorMap: Record<string, string> = {
    blue: 'stroke-blue-500',
    red: 'stroke-red-500',
    green: 'stroke-green-500'
  };

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="64"
            cy="64"
            r={radius}
            className="stroke-slate-700"
            strokeWidth="8"
            fill="transparent"
          />
          <circle
            cx="64"
            cy="64"
            r={radius}
            className={`${colorMap[color]} transition-all duration-500 ease-in-out`}
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            fill="transparent"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center transform rotate-0">
          <span className="text-2xl font-bold text-white">{Math.round(value)}%</span>
        </div>
      </div>
      <span className="mt-2 text-sm font-medium text-slate-400 uppercase tracking-wider">{label}</span>
    </div>
  );
};

export default Gauge;
