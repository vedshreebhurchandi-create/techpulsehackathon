
import React from 'react';
import { TankData, PumpStatus } from '../types';
import Gauge from './Gauge';

interface LocationCardProps {
  data: TankData;
  isSource?: boolean;
}

const LocationCard: React.FC<LocationCardProps> = ({ data, isSource }) => {
  const getStatusColor = (level: number) => {
    if (level < 10) return 'red';
    if (level < 30) return 'blue'; // Re-request state
    return 'blue';
  };

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden shadow-2xl flex flex-col h-full">
      <div className="bg-slate-700/50 px-4 py-3 flex justify-between items-center">
        <h3 className="font-semibold text-slate-200">{data.name}</h3>
        <span className={`px-2 py-0.5 rounded text-xs font-bold ${isSource ? 'bg-emerald-500/10 text-emerald-400' : 'bg-cyan-500/10 text-cyan-400'}`}>
          {isSource ? 'SOURCE' : 'DISTRIBUTION'}
        </span>
      </div>

      <div className="p-6 flex flex-col items-center gap-4">
        <Gauge value={data.level} label="Tank Level" color={getStatusColor(data.level)} />
        
        <div className="w-full grid grid-cols-2 gap-4 mt-2">
            <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Flow Rate</p>
                <p className="text-lg font-mono text-white">{data.flowRate.toFixed(1)} <span className="text-sm text-slate-400">L/s</span></p>
            </div>
            <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Last Heartbeat</p>
                <p className="text-lg font-mono text-white">ACTIVE</p>
            </div>
        </div>

        <div className="w-full space-y-3 mt-4">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-widest border-b border-slate-700 pb-2">Edge Control (ESP32)</p>
          {data.pumps.map((pump, idx) => (
            <div key={pump.id} className="flex items-center justify-between bg-slate-900 p-3 rounded-lg border border-slate-700/30">
              <div className="flex flex-col">
                <span className="text-sm font-medium text-slate-300">
                  {pump.isRedundant ? 'Backup Pump' : 'Main Pump'} 
                  <span className="ml-2 text-[10px] opacity-50 font-mono">#{pump.id}</span>
                </span>
                <span className="text-xs text-slate-500 font-mono">{pump.currentAmps.toFixed(2)}A Draw</span>
              </div>
              <div className="flex items-center gap-3">
                <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${
                  pump.actualStatus === PumpStatus.ON ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 
                  pump.actualStatus === PumpStatus.ERROR ? 'bg-red-500' : 'bg-slate-600'
                }`} />
                <span className={`text-[10px] font-bold ${
                   pump.actualStatus === PumpStatus.ON ? 'text-emerald-400' : 
                   pump.actualStatus === PumpStatus.ERROR ? 'text-red-400' : 'text-slate-500'
                }`}>
                  {pump.actualStatus}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LocationCard;
