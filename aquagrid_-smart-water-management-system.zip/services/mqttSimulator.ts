
import { GridState, PumpStatus } from '../types';
import { GRID_CONFIG } from '../constants';

export class MQTTSimulator {
  private state: GridState;
  private subscribers: ((state: GridState) => void)[] = [];
  private intervalId?: number;

  constructor() {
    this.state = {
      locationA: {
        id: 'loc-a',
        name: GRID_CONFIG.LOCATION_A.NAME,
        level: 85,
        flowRate: 12.5,
        lastUpdate: Date.now(),
        pumps: [
          { id: 'a-p1', command: PumpStatus.OFF, actualStatus: PumpStatus.OFF, currentAmps: 0, isRedundant: false },
          { id: 'a-p2', command: PumpStatus.OFF, actualStatus: PumpStatus.OFF, currentAmps: 0, isRedundant: true }
        ]
      },
      locationB: {
        id: 'loc-b',
        name: GRID_CONFIG.LOCATION_B.NAME,
        level: 45,
        flowRate: 0,
        lastUpdate: Date.now(),
        pumps: [
          { id: 'b-p1', command: PumpStatus.OFF, actualStatus: PumpStatus.OFF, currentAmps: 0, isRedundant: false },
          { id: 'b-p2', command: PumpStatus.OFF, actualStatus: PumpStatus.OFF, currentAmps: 0, isRedundant: true }
        ]
      },
      linkHealth: 100,
      alerts: []
    };
  }

  start() {
    this.intervalId = window.setInterval(() => {
      this.updateState();
      this.notify();
    }, 1000);
  }

  stop() {
    if (this.intervalId) clearInterval(this.intervalId);
  }

  private updateState() {
    // 1. Natural Consumption in Location B
    this.state.locationB.level -= 0.05;
    this.state.locationA.level -= 0.02;

    // 2. Inter-location Logic (MQTT logic Simulation)
    if (this.state.locationB.level < GRID_CONFIG.LOCATION_B.REQUEST_THRESHOLD) {
      if (this.state.locationA.level > GRID_CONFIG.LOCATION_A.THRESHOLD_MIN) {
        // Location A approves transfer
        this.state.locationA.pumps[0].command = PumpStatus.ON;
        this.state.locationA.pumps[0].actualStatus = PumpStatus.ON;
        this.state.locationA.pumps[0].currentAmps = 4.2;
        this.state.locationA.flowRate = 15.0;
        this.state.locationB.level += 0.15;
      }
    } else {
      this.state.locationA.pumps[0].command = PumpStatus.OFF;
      this.state.locationA.pumps[0].actualStatus = PumpStatus.OFF;
      this.state.locationA.pumps[0].currentAmps = 0;
      this.state.locationA.flowRate = 0;
    }

    // 3. Dry-run safety interrupt simulation
    if (this.state.locationA.level < GRID_CONFIG.LOCATION_A.CRITICAL_CUTOFF) {
       this.state.locationA.pumps.forEach(p => {
         p.command = PumpStatus.OFF;
         p.actualStatus = PumpStatus.OFF;
       });
       if (!this.state.alerts.find(a => a.message.includes("CRITICAL_CUTOFF"))) {
          this.addAlert('locationA', 'high', 'HARDWARE INTERRUPT: Dry-run prevented! All pumps disabled.');
       }
    }

    // 4. Random link health fluctuation
    this.state.linkHealth = Math.max(92, Math.min(100, this.state.linkHealth + (Math.random() - 0.5) * 2));
    
    this.state.locationA.lastUpdate = Date.now();
    this.state.locationB.lastUpdate = Date.now();
  }

  private addAlert(loc: string, severity: 'low'|'medium'|'high', message: string) {
    const alert = {
        id: Math.random().toString(36),
        timestamp: Date.now(),
        location: loc,
        severity,
        message
    };
    this.state.alerts = [alert, ...this.state.alerts].slice(0, 10);
  }

  forceFailure() {
    // Simulate Pump 1 failing while ON
    if (this.state.locationA.pumps[0].command === PumpStatus.ON) {
        this.state.locationA.pumps[0].currentAmps = 0;
        this.addAlert('locationA', 'medium', 'Self-Healing: Pump 1 failure detected (0A). Activating Redundant Pump 2.');
        this.state.locationA.pumps[0].actualStatus = PumpStatus.ERROR;
        this.state.locationA.pumps[1].command = PumpStatus.ON;
        this.state.locationA.pumps[1].actualStatus = PumpStatus.ON;
        this.state.locationA.pumps[1].currentAmps = 4.1;
    }
  }

  subscribe(callback: (state: GridState) => void) {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter(s => s !== callback);
    };
  }

  private notify() {
    this.subscribers.forEach(s => s({ ...this.state }));
  }
}

export const mqttBus = new MQTTSimulator();
