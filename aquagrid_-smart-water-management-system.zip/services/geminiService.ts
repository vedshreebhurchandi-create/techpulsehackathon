
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async getArchitectAdvice(query: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: query,
        config: {
          systemInstruction: "You are a Senior IoT Systems Architect. You specialize in industrial automation, MQTT protocols, and ESP32 edge logic for smart utility grids.",
          temperature: 0.7,
          thinkingConfig: { thinkingBudget: 4000 }
        }
      });
      return response.text;
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "Unable to connect to Architect AI at this moment.";
    }
  }
}

export const architectAI = new GeminiService();
